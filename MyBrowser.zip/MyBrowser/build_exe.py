import os
import sys
import subprocess

# Define the main script file and output executable name
MAIN_SCRIPT = "browser.py"  # Change this if your main script has a different name
OUTPUT_NAME = "CoolBrowser"  # Name of the final executable
ICON_PATH = "icons/browser_icon.ico"  # Path to the icon (optional)
USE_UPX = True  # Set to True to use UPX compression (if installed)

# Ensure all required packages are installed
print("\n🔄 Installing required packages...")
subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller", "PyQt5", "PyQtWebEngine"])

# Build the PyInstaller command
pyinstaller_cmd = [
    "pyinstaller",
    "--onefile",         # Pack everything into one file
    "--windowed",        # Hide console window
    f"--name={OUTPUT_NAME}",  # Set the output file name
]

# Add the icon if it exists
if os.path.exists(ICON_PATH):
    pyinstaller_cmd.append(f"--icon={ICON_PATH}")

# Exclude unnecessary libraries to reduce size
pyinstaller_cmd.extend([
    "--exclude numpy",
    "--exclude pandas",
])

# Add the main script at the end
pyinstaller_cmd.append(MAIN_SCRIPT)

# Run PyInstaller
print("\n🚀 Building the executable...")
subprocess.run(" ".join(pyinstaller_cmd), shell=True)

# Move the executable to the main project folder
exe_path = os.path.join("dist", f"{OUTPUT_NAME}.exe")
if os.path.exists(exe_path):
    print("\n✅ Build successful! Moving the executable...")
    os.rename(exe_path, f"./{OUTPUT_NAME}.exe")

# Cleanup build files
print("\n🧹 Cleaning up temporary files...")
subprocess.run(["rmdir", "/s", "/q", "build"], shell=True)  # Delete build folder
subprocess.run(["rmdir", "/s", "/q", "dist"], shell=True)  # Delete dist folder
subprocess.run(["del", "/f", "/q", f"{OUTPUT_NAME}.spec"], shell=True)  # Delete spec file

print("\n🎉 Done! Your standalone EXE is ready.\n")
