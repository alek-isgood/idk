import sys
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtGui import *

class Browser(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Cool Browser with Tabs and History")
        self.history_list = []  # Store visited pages
        self.bookmarks = []  # Store bookmarks
        self.private_mode = False  # Private browsing toggle

        self.tabs = QTabWidget(self)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.setCentralWidget(self.tabs)

        self.create_new_tab(QUrl("https://www.google.com"))
        self.create_navigation_bar()
        self.create_settings_menu()

    def create_navigation_bar(self):
        navbar = QToolBar("Navigation", self)
        self.addToolBar(navbar)

        back_btn = QAction(QIcon("icons/back.png"), "Back", self)
        back_btn.triggered.connect(self.go_back)
        navbar.addAction(back_btn)

        forward_btn = QAction(QIcon("icons/forward.png"), "Forward", self)
        forward_btn.triggered.connect(self.go_forward)
        navbar.addAction(forward_btn)

        reload_btn = QAction(QIcon("icons/reload.png"), "Reload", self)
        reload_btn.triggered.connect(self.reload_page)
        navbar.addAction(reload_btn)

        home_btn = QAction(QIcon("icons/home.png"), "Home", self)
        home_btn.triggered.connect(self.go_home)
        navbar.addAction(home_btn)

        new_tab_btn = QAction(QIcon("icons/newtab.png"), "New Tab", self)
        new_tab_btn.triggered.connect(self.create_new_tab)
        navbar.addAction(new_tab_btn)

        self.url_bar = QLineEdit(self)
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        navbar.addWidget(self.url_bar)

        bookmark_btn = QAction(QIcon("icons/bookmark.png"), "Bookmark", self)
        bookmark_btn.triggered.connect(self.add_bookmark)
        navbar.addAction(bookmark_btn)

        history_btn = QAction(QIcon("icons/history.png"), "History", self)
        history_btn.triggered.connect(self.show_history)
        navbar.addAction(history_btn)

    def create_settings_menu(self):
        settings_menu = self.menuBar().addMenu("Settings")

        private_mode_action = QAction("Private Mode", self, checkable=True)
        private_mode_action.triggered.connect(self.toggle_private_mode)
        settings_menu.addAction(private_mode_action)

    def toggle_private_mode(self, checked):
        self.private_mode = checked
        if self.private_mode:
            print("Private Browsing Enabled (No History Saved)")
        else:
            print("Private Browsing Disabled")

    def create_new_tab(self, url=QUrl("about:blank")):
        browser_view = QWebEngineView(self)
        browser_view.setUrl(url)
        browser_view.urlChanged.connect(self.update_url)
        browser_view.loadFinished.connect(self.on_load_finished)

        # Handle downloads
        profile = browser_view.page().profile()
        profile.downloadRequested.connect(self.handle_download)

        tab_index = self.tabs.addTab(browser_view, "New Tab")
        self.tabs.setCurrentIndex(tab_index)

    def close_tab(self, index):
        if self.tabs.count() > 1:
            self.tabs.removeTab(index)
        else:
            self.create_new_tab(QUrl("https://www.google.com"))
            self.tabs.removeTab(0)

    def go_back(self):
        self.get_current_tab().back()

    def go_forward(self):
        self.get_current_tab().forward()

    def reload_page(self):
        self.get_current_tab().reload()

    def go_home(self):
        self.get_current_tab().setUrl(QUrl("https://www.google.com"))

    def get_current_tab(self):
        return self.tabs.currentWidget()

    def update_url(self, url):
        self.url_bar.setText(url.toString())
        if not self.private_mode:
            self.history_list.append(url.toString())

    def navigate_to_url(self):
        url = self.url_bar.text()
        self.get_current_tab().setUrl(QUrl(url))

    def on_load_finished(self):
        current_tab = self.get_current_tab()
        title = current_tab.page().title()
        current_index = self.tabs.currentIndex()
        self.tabs.setTabText(current_index, title if title else "Untitled")

    def show_history(self):
        history_dialog = QDialog(self)
        history_dialog.setWindowTitle("Browsing History")
        history_dialog.setGeometry(100, 100, 400, 300)

        layout = QVBoxLayout()
        history_list_widget = QListWidget()

        for url in self.history_list:
            history_list_widget.addItem(url)

        layout.addWidget(history_list_widget)
        history_dialog.setLayout(layout)
        history_dialog.exec_()

    def add_bookmark(self):
        url = self.url_bar.text()
        if url and url not in self.bookmarks:
            self.bookmarks.append(url)
            QMessageBox.information(self, "Bookmark Added", f"{url} added to bookmarks.")

    def handle_download(self, download):
        path, _ = QFileDialog.getSaveFileName(self, "Save File", download.suggestedFileName())
        if path:
            download.setPath(path)
            download.accept()

def main():
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icons/browser_icon.png"))

    window = Browser()
    window.showMaximized()
    app.exec_()

if __name__ == "__main__":
    main()
